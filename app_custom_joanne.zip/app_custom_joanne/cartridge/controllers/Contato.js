'use strict';

var server = require('server');
//actionUrl tem que ser igual no isml dele tbm

server.get('CadFornecedores', server.middleware.https, function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var contactFornecedores = server.forms.getForm('contactInfo');//Voltar o frmulario usando o ID do xml
    res.render('/contForm/contactBR', {//isml criado no template
        actionUrl: URLUtils.url('Contato-Subscribe').toString(),//o nme do controler para enviar mensagem
        contactFornecedores:contactFornecedores
    });

    next();
});

//server.post('Subscribe', server.middleware.https, function (req, res, next) {
  //  var Resource = require('dw/web/Resource');
    //var hooksHelper = require('*/cartridge/scripts/helpers/hooks');
    //var emailHelper = require('*/cartridge/scripts/helpers/emailHelpers');

    //var myForm = req.form;
    //var customObjMgr = require('dw/object/CustomObjectMgr');
    //customObjMgr.createCustomObject('Newsletter', newsletterForm.contactInfoFields.email.value);

    //var isValidEmailid = emailHelper.validateEmail(myForm.email);
    //if (isValidEmailid) {
      //  var contactDetails = [ myForm.name, myForm.email, myForm.phone];//depois do myForm. colocar o Id

        //res.json({
          //  success: true,
            //msg: Resource.msg('subscribe.to.contact.us.success', 'contactUs', null)
       // });
    /*} else {
        res.json({
            error: true,
            msg: Resource.msg('subscribe.to.contact.us.email.invalid', 'contactUs', null)
        });
    }

    next();
});*/
server.post('Subscribe', server.middleware.https, function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');
    var emailHelpers = require('*/cartridge/scripts/helpers/emailHelpers');
    var contactFornecedores = server.forms.getForm('contactInfo');
    var formErrors = require('*/cartridge/scripts/formErrors');

if (contactFornecedores.valid){
    var transaction=require('dw/system/Transaction');
    var customObjMgr = require('dw/object/CustomObjectMgr');
    transaction.wrap(function(){
        var recebe= customObjMgr.createCustomObject('fornecedores', contactFornecedores.cnpj.value);
        recebe.custom.nomecontato=contactFornecedores.contato.value;
        recebe.custom.phone=contactFornecedores.phone.value;
        recebe.custom.cep=contactFornecedores.cep.value;
        recebe.custom.endereco=contactFornecedores.endereco.value;
        recebe.custom.razao=contactFornecedores.razao.value;
        recebe.custom.nomefantasia=contactFornecedores.nomefantasia.value;
        recebe.custom.email=contactFornecedores.email.value;
        recebe.custom.estado=contactFornecedores.estado.value;
    });
    
    var Site=require('dw/system/Site');
    var recebeObject={
        razao: contactFornecedores.razao.value,
        fantasia: contactFornecedores.nomefantasia.value
        
    };
    var emailObj = {
        to:contactFornecedores.email.value|| 'fale.joanne@gmail.com',
        subject:'Novo Fornecedor Cadastrado com Sucesso',
        from: Site.current.getCustomPreferenceValue('custumerServiceEmail') || 'fale.joanne@gmail.com',
        type: emailHelpers.emailTypes.registration
    };
    
    emailHelpers.send(emailObj,'/contForm/contForn',recebeObject);
    res.render('/contForm/contactManda', {//isml criado no template
         contactFornecedores:contactFornecedores
    });
    } else {
    res.json({
        success: false,
        fields: formErrors.getFormErrors(contactFornecedores)
    });
}
    return next();
});

module.exports = server.exports();
